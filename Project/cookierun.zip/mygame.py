import game_framework
import pico2d

import title_kpu_state

# fill here
pico2d.open_canvas(800, 500)
game_framework.run(title_kpu_state)
pico2d.close_canvas()